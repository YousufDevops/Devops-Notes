
* Deployment & Service
* NGINX Ingress Installation (Helm)
* Ingress Resource Setup
* `/etc/hosts` changes (Linux & Windows)
* Browser Access Options
* NodePort vs LoadBalancer
* Tips & Troubleshooting

---


#  Complete Kubernetes Ingress Setup on AWS EKS (With NGINX Ingress Controller)

---

##  1. Deploy Java Web Application (Deployment + Service)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: javawebappdep
  namespace: test-ns
spec:
  replicas: 2
  strategy:
    type: Recreate
  selector:
    matchLabels:
      app: javawebapp
  template:
    metadata:
      name: javawebapp
      labels:
        app: javawebapp
    spec:
      containers:
      - name: javawebapp
        image: kkeducation12345/spring-app:1.0.5
        ports:
        - containerPort: 8080
---
apiVersion: v1
kind: Service
metadata:
  name: javawebappsvc
  namespace: test-ns
spec:
  type: NodePort
  selector:
    app: javawebapp
  ports:
  - port: 80
    targetPort: 8080
````

---

##  2. Install NGINX Ingress Controller Using Helm

```bash
# Install Helm (if not installed)
curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 | bash

# Add NGINX Helm Repo
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

# Install Ingress Controller
helm install ingress-nginx ingress-nginx/ingress-nginx --namespace ingress-nginx --create-namespace
```

---

##  3. Check Ingress Controller LoadBalancer IP

```bash
kubectl get svc -n ingress-nginx
```

Example:

```
ingress-nginx-controller LoadBalancer a8c9a4e82fb4d4726bb07851f26acae8-1810291130.ap-south-1.elb.amazonaws.com
```

---

##  4. Create Ingress Resource

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: javawebapp-ingress
  namespace: test-ns
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  rules:
  - host: javawebapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: javawebappsvc
            port:
              number: 80
```

Apply:

```bash
kubectl apply -f javawebapp-ingress.yaml
```

---

##  5. Update `/etc/hosts` for DNS Mapping (Linux & Windows)

### ➜ Find LoadBalancer IP:

```bash
nslookup a8c9a4e82fb4d4726bb07851f26acae8-1810291130.ap-south-1.elb.amazonaws.com
```

Example IPs:

```
15.206.18.139
3.6.27.227
```

### ➜ Add Entry:

####  On Linux:

```bash
sudo vi /etc/hosts
```

Add:

```
15.206.18.139 javawebapp.example.com
3.6.27.227 javawebapp.example.com
```

####  On Windows:

1. Open Notepad as Administrator.
2. Open:

```
C:\Windows\System32\drivers\etc\hosts
```

3. Add:

```
15.206.18.139 javawebapp.example.com
3.6.27.227 javawebapp.example.com
```

4. Save.

---

## 6. Access From Browser

Open:

```
http://javawebapp.example.com
```

 Now your app is accessible via browser.

---

##  7. NodePort vs LoadBalancer (Best Practice)

| Method                 | Purpose             | Notes                       |
| ---------------------- | ------------------- | --------------------------- |
| NodePort               | Internal Testing    | Needs Node Public IP + Port |
| LoadBalancer (Ingress) | Best for Production | Easy DNS, SSL, Clean URLs   |

---

##  Tips:

* For quick testing, use `/etc/hosts`.
* In production, use AWS Route53 for DNS mapping.
* You can remove `host` from Ingress YAML for quick testing without DNS.

---

##  Troubleshooting:

| Issue                    | Solution                                                         |
| ------------------------ | ---------------------------------------------------------------- |
| Could not resolve host   | Check `/etc/hosts` entries or DNS                                |
| 404 Not Found on Browser | Check Ingress paths & services                                   |
| LoadBalancer Pending     | Wait, check AWS console                                          |
| Ingress Not Working      | Check IngressClassName and logs: `kubectl logs -n ingress-nginx` |

---

##  Diagram:

```
Browser → AWS LoadBalancer (Ingress) → NGINX Ingress → Service (NodePort) → Pods
```


